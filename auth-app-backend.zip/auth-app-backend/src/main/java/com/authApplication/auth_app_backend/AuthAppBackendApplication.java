package com.authApplication.auth_app_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AuthAppBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(AuthAppBackendApplication.class, args);
	}


}
