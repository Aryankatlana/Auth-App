package com.authApplication.auth_app_backend.entities;

public enum Provider {

    LOCAL, GOOGLE, GITHUB
}
